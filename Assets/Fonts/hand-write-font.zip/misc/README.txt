This font is for PERSONAL USE ONLY , not allowed for commercial use in any form.

but if you are interested in buying it, visit:
https://www.creativefabrica.com/designer/jadatype

or contact me : jadaakbaaal@gmail.com

Thank you and happy using!
Jadatype